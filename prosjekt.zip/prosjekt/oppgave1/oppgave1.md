# Kladd for prosjekt
## Oppgave 1
### 5.1.21
Må bevise at 2. ordens formelen for den fjerdederiverte er gitt ved:
$$f^{(iv)}(x)=\frac{f(x-2h)-4f(x-h)+6f(x)-4f(x+h)+f(x+2h)}{h^4}+O(h^2)$$
#### Bevis
Taylors teorem sier oss at dersom $f$ er 6 ganger derivervar og kontinuerlig, så blir Taylor ekspansjonen til $f(x-2h)$ og $f(x+2h)$ følgende:
$$
\begin{aligned}
f(x-2h)&=\left(\sum_{i=0}^5{\frac{(-2h)^i}{i!}f^{(i)}(x)}\right)+\frac{4h^6}{45}f^{(vi)}(c_1) \\
&= f(x)-2hf'(x)+2h^2f''(x)-\frac{4h^3}{3}f'''(x)+\frac{2h^4}{3}f^{(iv)}(x)-\frac{4h^5}{15}f^{(v)}(x)+\frac{4h^6}{45}f^{(vi)}(c_1)
\end{aligned}
$$
og
$$
\begin{aligned}
f(x+2h)&=\left(\sum_{i=0}^5{\frac{(2h)^i}{i!}f^{(i)}(x)}\right)+\frac{4h^6}{45}f^{(vi)}(c_2) \\
&= f(x)+2hf'(x)+2h^2f''(x)+\frac{4h^3}{3}f'''(x)+\frac{2h^4}{3}f^{(iv)}(x)+\frac{4h^5}{15}f^{(v)}(x)+\frac{4h^6}{45}f^{(vi)}(c_2)
\end{aligned}
$$
Vi får at:
$$f(x-2h)+f(x+2h)=2f(x)+4h^2f''(x)+\frac{4h^4}{3}f^{(iv)}(x)+\frac{8h^6}{45}f^{(vi)}(c_3)\quad\quad(1)$$

Taylor ekspansjonen til $f(x-h)$ og $f(x+h)$ blir følgende:
$$
\begin{aligned}
f(x-h)&=\left(\sum_{i=0}^5{\frac{(-h)^i}{i!}f^{(i)}(x)}\right)+\frac{h^6}{720}f^{(vi)}(c_4) \\
&= f(x)-hf'(x)+\frac{h^2}{2}f''(x)-\frac{h^3}{6}f'''(x)+\frac{h^4}{24}f^{(iv)}(x)-\frac{h^5}{120}f^{(v)}(x)+\frac{h^6}{720}f^{(vi)}(c_4)
\end{aligned}
$$
og
$$
\begin{aligned}
f(x+h)&=\left(\sum_{i=0}^5{\frac{h^i}{i!}f^{(i)}(x)}\right)+\frac{h^6}{720}f^{(vi)}(c_5) \\
&= f(x)+hf'(x)+\frac{h^2}{2}f''(x)+\frac{h^3}{6}f'''(x)+\frac{h^4}{24}f^{(iv)}(x)+\frac{h^5}{120}f^{(v)}(x)+\frac{h^6}{720}f^{(vi)}(c_5)
\end{aligned}
$$
Vi får at:
$$
\begin{aligned}
f(x-h)+f(x+h)&=2f(x)+h^2f''(x)+\frac{h^4}{12}f^{(iv)}(x)+\frac{h^6}{360}f^{(vi)}(c_6)\implies \\
4f(x-h)+4f(x+h)&=8f(x)+4h^2f''(x)+\frac{h^4}{3}f^{(iv)}(x)+\frac{h^6}{90}f^{(vi)}(c_6)\quad\quad(2)
\end{aligned}
$$
Skriver om likningene (1) og (2):
$$
\begin{aligned}
(1)\quad\quad 4h^2f''(x)&=f(x-2h)+f(x+2h)-2f(x)-\frac{4h^4}{3}f^{(iv)}(x)-\frac{8h^6}{45}f^{(vi)}(c_3) \\
(2)\quad\quad 4h^2f''(x)&=4f(x-h)+4f(x+h)-8f(x)-\frac{h^4}{3}f^{(iv)}(x)-\frac{h^6}{90}f^{(vi)}(c_6)
\end{aligned}
$$
Dette gir oss følgende likhet:
$$f(x-2h)+f(x+2h)-2f(x)-\frac{4h^4}{3}f^{(iv)}(x)-\frac{8h^6}{45}f^{(vi)}(c_3) = 4f(x-h)+4f(x+h)-8f(x)-\frac{h^4}{3}f^{(iv)}(x)-\frac{h^6}{90}f^{(vi)}(c_6)$$
Skriver om:
$$\begin{aligned}
h^4f^{(iv)}(x) &= f(x-2h)-4f(x-h)-2f(x)+8f(x)-4f(x+h)+f(x+2h)+O(h^6)\implies \\
f^{(iv)}(x) &= \frac{f(x-2h)-4f(x-h)+6f(x)-4f(x+h)+f(x+2h)}{h^4}+O(h^2)\quad\blacksquare
\end{aligned}
$$

### 5.1.22a

La $f(x)$ være en seks ganger kontinuerlig deriverbar funksjon. Må bevise at hvis $f(x)=f'(x)=0$, så vil
$$f^{(iv)}(x+h)-\frac{16f(x+h)-9f(x+2h)+\frac{8}{3}f(x+3h)-\frac{1}{4}f(x+h)}{h^4}=O(h^2)\quad\quad(1)$$

#### Bevis
Starter med å bevise følgende likhet:

$$f(x-h)-10f(x+h)+5f(x+2h)-\frac{5}{3}f(x+3h)+\frac{1}{4}f(x+4h)=O(h^6)\quad\quad(2)$$

Bruker Taylors teorem til å utlede uttrykk for $f(x+3h)$ og $f(x+4h)$:
$$\begin{aligned}
f(x+3h)&=\left(\sum_{i=0}^5{\frac{(3h)^i}{i!}f^{(i)}(x)}\right)+\frac{81h^6}{80}f^{(vi)}(c_3) \\
&= f(x)+3hf'(x)+\frac{9}{2}h^2f''(x)+\frac{9h^3}{28}f'''(x)+\frac{27h^4}{8}f^{(iv)}(x)+\frac{81h^5}{40}f^{(v)}(x)+\frac{81h^6}{80}f^{(vi)}(c_3)
\end{aligned}$$
og
$$\begin{aligned}
f(x+4h)&=\left(\sum_{i=0}^5{\frac{(4h)^i}{i!}f^{(i)}(x)}\right)+\frac{256h^6}{45}f^{(vi)}(c_4) \\
&= f(x)+4hf'(x)+8h^2f''(x)+\frac{32h^3}{3}f'''(x)+\frac{32h^4}{3}f^{(iv)}(x)+\frac{128h^5}{15}f^{(v)}(x)+\frac{256h^6}{45}f^{(vi)}(c_4)
\end{aligned}$$

Ved å multiplisere uttrykkene for $f(x-h), f(x+h), f(x+2h), f(x+3h) \text{ og } f(x+4h)$ med henholdsvis $1, -10, 5, -\frac{5}{3} \text{ og } \frac{1}{4}$, og å summere dem sammen samtidig som man bruker at $f(x)=f'(x)=0$, så får vi at:
$$f(x-h)-10f(x+h)+5f(x+2h)-\frac{5}{3}f(x+3h)+\frac{1}{4}f(x+4h)=O(h^6)$$

Fra 5.1.21 har vi at:
$$f^{(iv)}(x) = \frac{f(x-2h)-4f(x-h)+6f(x)-4f(x+h)+f(x+2h)}{h^4}+O(h^2)$$

Da blir uttrykket for $f(x+h)$ følgende:
$$f^{(iv)}(x+h) = \frac{f(x-h)-4f(x)+6f(x+h)-4f(x+2h)+f(x+3h)}{h^4}+O(h^2)$$

Setter inn uttrykket i (1):

$$\begin{aligned}f^{(iv)}(x+h)-\frac{16f(x+h)-9f(x+2h)+\frac{8}{3}f(x+3h)-\frac{1}{4}f(x+h)}{h^4}&=O(h^2)\\ 
\frac{f(x-h)-4f(x)+6f(x+h)-4f(x+2h)+f(x+3h)-16f(x+h)-9f(x+2h)+\frac{8}{3}f(x+3h)-\frac{1}{4}f(x+h)}{h^4}&=O(h^2) \\
\end{aligned}$$
Setter $f(x)=0$, og får til slutt at:

$$\begin{aligned}
\frac{f(x-h)-10f(x+h)+5f(x+2h)-\frac{5}{3}f(x+3h)+\frac{1}{4}f(x+4h)}{h^4} &= O(h^2) \implies \\
f(x-h)-10f(x+h)+5f(x+2h)-\frac{5}{3}f(x+3h)+\frac{1}{4}f(x+4h) &= O(h^6)
\end{aligned}$$

Vi ender opp med likning (2), noe som betyr at (1) stemmer hvis $f(x)=f'(x)=0\quad\blacksquare$