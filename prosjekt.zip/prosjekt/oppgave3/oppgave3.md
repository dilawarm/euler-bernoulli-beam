# Oppgave 3 kladd

Skal finne løsningen $y_c$ på problemet med en bjelke uten ekstra masse enn egenmassen ved å bruke $n=10$ intervaller. La $A$ være matrisen fra oppgave 2. Siden $n=10$:
$$\begin{aligned}h&=\frac{L}{n}=\frac{2}{10}=0.2\\
b&=\left[\frac{h^4}{E\cdot I}\cdot f\right]_{n\text{ x }1}
\end{aligned}
$$ 

Skal løse likningen $Ay=b$ for å finne løsningen på problemet. Se matlabkoden for oppgave 3.
Vi får at
$$y=\begin{bmatrix}
-0.000180624738461544\\
-0.000674847507692328\\
-0.00141698658461543\\
-0.00234908750769237\\
-0.00342092307692317\\
-0.00458999335384627\\
-0.0058215256615386\\
-0.00708847458461555\\
-0.00837152196923095\\
-0.00965907692307711\\
\end{bmatrix}$$

Dette er forskyvningen stupebrettet har pga. sin egenmasse. Nedenfor er et bilde av hvordan denne bøyningen ser ut, hvor x-aksen er lengden i meter, og y-aksen er forskyvningen i meter.
![](oppgave3.jpg)