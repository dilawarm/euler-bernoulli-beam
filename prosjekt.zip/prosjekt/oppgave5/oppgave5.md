# Oppgave 5 kladd

Kjører utregningene i oppgave 3 om igjen for $n=10,40,\dots,10\cdot 2^{11}$. Nedenfor er det en tabell over feilen i punktet $x=L$ for hver $n$, samt kondisjonstallet til $A$ for de forskjellige verdiene av $n$:
![](tabell.jpg)
Vi ser fra tabellen at den absolutte feilen er størst for $n=10240$. Feilen endrer seg med $n$ som den gjør fordi kondisjonstallet til $A$ blir større når $n$ blir større. Dette medfører at sjansen for avrundingsfeil øker.